import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayTimeRoute4Component } from './display-time-route4.component';

describe('DisplayTimeRoute4Component', () => {
  let component: DisplayTimeRoute4Component;
  let fixture: ComponentFixture<DisplayTimeRoute4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayTimeRoute4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayTimeRoute4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
