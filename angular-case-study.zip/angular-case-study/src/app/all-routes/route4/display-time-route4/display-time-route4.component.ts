import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CountDownTimerService } from '../count-down-timer.service';

@Component({
  selector: 'app-display-time-route4',
  templateUrl: './display-time-route4.component.html',
  styleUrls: ['./display-time-route4.component.css']
})
export class DisplayTimeRoute4Component implements OnInit,OnDestroy {

  localTimerVal: number = 0;
  interval:any;
  timerSubjectSub:Subscription;

  constructor(private countDownTimerSer : CountDownTimerService) { }

  ngOnInit(): void {
    this.timerSubjectSub = this.countDownTimerSer.calculateTimerSub.subscribe(data => {
      if (data.timerLim && data.btnStatus === 'start') {
        if (!this.localTimerVal)
          this.localTimerVal = data.timerLim
        this.interval = setInterval(() => {
          this.localTimerVal--
          if (this.localTimerVal === 0)
            this.pauseTimer();
        }, 1000)
      }
      else if (data.btnStatus === 'reset') {
        this.localTimerVal = 0
        this.pauseTimer()
      }
      else if (data.btnStatus === 'pause') {
        this.pauseTimer();
        this.countDownTimerSer.displayPausedValSub.next(this.localTimerVal);
      }
    })
  }

  pauseTimer() {
    clearInterval(this.interval);
  }

  ngOnDestroy(){
    this.timerSubjectSub.unsubscribe();
  }

}
