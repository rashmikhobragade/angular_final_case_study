import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogTimeRoute4Component } from './log-time-route4.component';

describe('LogTimeRoute4Component', () => {
  let component: LogTimeRoute4Component;
  let fixture: ComponentFixture<LogTimeRoute4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogTimeRoute4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogTimeRoute4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
