import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CountDownTimerService } from '../count-down-timer.service';

@Component({
  selector: 'app-log-time-route4',
  templateUrl: './log-time-route4.component.html',
  styleUrls: ['./log-time-route4.component.css']
})
export class LogTimeRoute4Component implements OnInit,OnDestroy {

  logTimeArr = [];
  timerValueSub:Subscription;

  constructor(private countDownTimerSer : CountDownTimerService) { }

  ngOnInit(): void {
    this.timerValueSub = this.countDownTimerSer.calculateTimerSub.subscribe(data =>{
      if(data.btnStatus === 'reset')
      this.logTimeArr = [];
      else
      this.logTimeArr.push({time:data.time,status:data.btnStatus});
    })
  }

  ngOnDestroy(){
    this.timerValueSub.unsubscribe();
  }

}
