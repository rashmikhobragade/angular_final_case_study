import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputTimerLimitRoute4Component } from './input-timer-limit-route4.component';

describe('InputTimerLimitRoute4Component', () => {
  let component: InputTimerLimitRoute4Component;
  let fixture: ComponentFixture<InputTimerLimitRoute4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputTimerLimitRoute4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InputTimerLimitRoute4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
