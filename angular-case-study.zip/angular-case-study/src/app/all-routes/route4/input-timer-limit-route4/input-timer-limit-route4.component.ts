import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CountDownTimerService } from '../count-down-timer.service';

@Component({
  selector: 'app-input-timer-limit-route4',
  templateUrl: './input-timer-limit-route4.component.html',
  styleUrls: ['./input-timer-limit-route4.component.css']
})
export class InputTimerLimitRoute4Component implements OnInit,OnDestroy {

  timerLim: number;
  resetButton: boolean = true;
  btnStatus: string = '';
  startCount = 0;
  pauseCount = 0;
  pauseValArr : number[] = [];
  pauseValSubscription: Subscription;

  constructor(private countDownTimerSer: CountDownTimerService) { }

  ngOnInit(): void {
    this.pauseValSubscription = this.countDownTimerSer.displayPausedValSub.subscribe((data:number) =>{
      this.pauseValArr.push(data);
    })
  }

  startTimer() {
    if (this.timerLim && this.timerLim !== 0 && !this.timerLim.toString().includes('.')) {
      this.btnStatus = this.btnStatus === '' || this.btnStatus === 'pause' || this.btnStatus === 'reset' ? 'start' : 'pause';
      if (this.btnStatus === 'pause')
        this.pauseCount++
      else if (this.btnStatus === 'start')
        this.startCount++
      this.resetButton = false;
      this.countDownTimerSer.calculateTimer(this.timerLim, this.btnStatus, this.startCount, this.pauseCount);
    }
  }

  resetTimer() {
    this.btnStatus = 'reset';
    this.resetButton = true;
    this.resetAllValues();
    this.countDownTimerSer.calculateTimer(this.timerLim, this.btnStatus, this.startCount, this.pauseCount);
  }

  resetAllValues() {
    this.timerLim = 0;
    this.startCount = 0;
    this.pauseCount = 0;
    this.pauseValArr = [];
  }

  ngOnDestroy(){
    this.pauseValSubscription.unsubscribe();
  }
}
