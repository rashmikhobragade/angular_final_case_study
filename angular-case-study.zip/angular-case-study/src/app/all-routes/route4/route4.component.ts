import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route4',
  templateUrl: './route4.component.html',
  styleUrls: ['./route4.component.css']
})
export class Route4Component implements OnInit {

  timerVal:number;
  btnStatus:string;
  logTimeVal:string;
  pauseCount:number;
  startCount:number;
  
  constructor() { }

  ngOnInit(): void {
  }

  timerValReceived(data:any){
    this.timerVal = data.timerLim
    this.btnStatus = data.btnStatus
    this.logTimeVal = data.time;
    this.pauseCount = data.pauseCount;
    this.startCount = data.startCount;
  }
}
