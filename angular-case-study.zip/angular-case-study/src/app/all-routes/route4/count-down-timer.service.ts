import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CountDownTimerService {

  calculateTimerSub = new Subject<any>();
  displayPausedValSub = new Subject<number>();

  constructor() { }

  calculateTimer(timerLim:number,btnStatus:string,startCount:number,pauseCount:number){
    const timerValues = {
      timerLim : timerLim,
      btnStatus: btnStatus,
      startCount:startCount,
      pauseCount:pauseCount,
      time:this.getDateAndTime()
    }
    this.calculateTimerSub.next(timerValues);
  }

  getDateAndTime() {
    const date = new Date();
    const month = date.getMonth() + 1;
    return `${date.getDate()}-${month}-${date.getFullYear()} ${date.toLocaleTimeString()}`;
  }

}
