import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClickCountRoute4Component } from './click-count-route4.component';

describe('ClickCountRoute4Component', () => {
  let component: ClickCountRoute4Component;
  let fixture: ComponentFixture<ClickCountRoute4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClickCountRoute4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClickCountRoute4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
