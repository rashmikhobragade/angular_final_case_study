import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CountDownTimerService } from '../count-down-timer.service';

@Component({
  selector: 'app-click-count-route4',
  templateUrl: './click-count-route4.component.html',
  styleUrls: ['./click-count-route4.component.css']
})
export class ClickCountRoute4Component implements OnInit,OnDestroy {
  
  startCount:number = 0;
  pauseCount:number = 0;
  timerValueSub:Subscription;

  constructor(private countDownTimerSer : CountDownTimerService) { }

  ngOnInit(): void {
    this.timerValueSub = this.countDownTimerSer.calculateTimerSub.subscribe(data => {
      this.startCount = data.startCount;
      this.pauseCount = data.pauseCount;
    })
  }

  ngOnDestroy(){
    this.timerValueSub.unsubscribe();
  }
}
