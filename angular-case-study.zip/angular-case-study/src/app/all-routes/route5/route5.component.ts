import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route5',
  templateUrl: './route5.component.html',
  styleUrls: ['./route5.component.css']
})
export class Route5Component implements OnInit {

  headerNames:string[] = [];
  studentData:any[] = [];
  sortOrder:string='reset';
  sortBy:string;

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get('./assets/data/data.json').subscribe((data:any[]) => {
      this.headerNames = Object.keys(data[0]);
      this.studentData = data;
    })
  }

  onSelect(item){
    this.sortBy = item;
    this.sortOrder==='reset'?this.sortOrder='asc':
    (this.sortOrder==='asc'?this.sortOrder='desc':
    (this.sortOrder==='desc'?this.sortOrder='reset':''));
  }

}
