import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(value: any[],sortBy:string,sortOrder:string): any {
    if(value){
      if(sortOrder==='reset')
        return value
      else if(sortOrder === 'asc'){
        let updValue = [...value]
        return updValue.sort((a,b):any=>{
          if(a[sortBy]>b[sortBy])return 1
           if(b[sortBy]>a[sortBy])return -1
          })
      }
      else if(sortOrder === 'desc'){
        let udpVal = [...value]
        return udpVal.sort((a,b):any=>{
          if(a[sortBy]>b[sortBy])return -1
           if(a[sortBy]>b[sortBy])return 1
          })
      }
      return value
    }
  }

}
