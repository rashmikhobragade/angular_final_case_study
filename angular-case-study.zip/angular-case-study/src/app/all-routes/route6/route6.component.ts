import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route6',
  templateUrl: './route6.component.html',
  styleUrls: ['./route6.component.css']
})
export class Route6Component implements OnInit {
  lastScrollTop:number = 0;
  numArray:number[]=[1,2]

  constructor() { }

  ngOnInit(): void {}

  onScroll(event){
    let current = event.target.scrollTop;
    if(current > this.lastScrollTop && current - this.lastScrollTop > 200){
      this.numArray.push(this.numArray.length+1)
      this.lastScrollTop = current;
      console.log(this.numArray,'this.numArray')
    }
  }

  showAlertMsg(item){
    alert(`Button in ${item} div clicked`);
  }
}
