import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AllRoutesComponent } from './all-routes.component';
import { Route1Component } from './route1/route1.component';
import { Route2Component } from './route2/route2.component';
import { FilterPipe } from './route2/filter.pipe';
import { Route3Component } from './route3/route3.component';
import { DisplayTimerComponent } from './route3/display-timer/display-timer.component';
import { InputTimerLimitComponent } from './route3/input-timer-limit/input-timer-limit.component';
import { LogTimeComponent } from './route3/log-time/log-time.component';
import { ClickCountComponent } from './route3/click-count/click-count.component';
import { Route4Component } from './route4/route4.component';
import { DisplayTimeRoute4Component } from './route4/display-time-route4/display-time-route4.component';
import { ClickCountRoute4Component } from './route4/click-count-route4/click-count-route4.component';
import { InputTimerLimitRoute4Component } from './route4/input-timer-limit-route4/input-timer-limit-route4.component';
import { LogTimeRoute4Component } from './route4/log-time-route4/log-time-route4.component';
import { Route5Component } from './route5/route5.component';
import { SortPipe } from './route5/sort.pipe';
import { Route6Component } from './route6/route6.component';
import { AllRoutesRoutingModule } from './all-routes-routing.module';

@NgModule({
  declarations: [
    Route1Component,
    Route5Component,
    SortPipe,
    Route6Component,
    Route3Component,
    DisplayTimerComponent,
    InputTimerLimitComponent,
    LogTimeComponent,
    ClickCountComponent,
    Route2Component,
    FilterPipe,
    Route4Component,
    DisplayTimeRoute4Component,
    ClickCountRoute4Component,
    InputTimerLimitRoute4Component,
    LogTimeRoute4Component,
    AllRoutesComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    AllRoutesRoutingModule
  ]
})
export class AllRoutesModule { }
