import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route3',
  templateUrl: './route3.component.html',
  styleUrls: ['./route3.component.css']
})
export class Route3Component implements OnInit {

  timerVal:number;
  btnStatus:string;
  logTimeVal:string;
  pauseCount:number;
  startCount:number;
  pauseValue:number;

  constructor() { }

  ngOnInit(): void {
  }

  timerValReceived(data:any){
    this.timerVal = data.timerLim
    this.btnStatus = data.btnStatus
    this.logTimeVal = data.time;
    this.pauseCount = data.pauseCount;
    this.startCount = data.startCount;
  }

  pauseValEvent(data:number){
    this.pauseValue = data;
  }
}
