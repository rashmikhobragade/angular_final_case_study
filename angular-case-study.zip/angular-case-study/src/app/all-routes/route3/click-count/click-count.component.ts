import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-click-count',
  templateUrl: './click-count.component.html',
  styleUrls: ['./click-count.component.css']
})
export class ClickCountComponent implements OnInit {

  @Input() pauseCount:number;
  @Input() startCount:number;
  constructor() { }

  ngOnInit(): void {
  }

}
