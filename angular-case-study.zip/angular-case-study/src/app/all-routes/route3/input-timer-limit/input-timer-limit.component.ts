import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-input-timer-limit',
  templateUrl: './input-timer-limit.component.html',
  styleUrls: ['./input-timer-limit.component.css']
})
export class InputTimerLimitComponent implements OnInit, OnChanges {

  @Input() pauseValue:number;
  @Output() calculateTimerEvent = new EventEmitter<any>();

  timerLim: number;
  resetButton: boolean = true;
  btnStatus: string = '';
  startCount = 0;
  pauseCount = 0;
  pauseValArr:number[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes:SimpleChanges){
    if (!changes.pauseValue?.firstChange)
      this.pauseValArr.push(this.pauseValue)
  }

  startTimer() {
    if(this.timerLim && this.timerLim !== 0 && !this.timerLim.toString().includes('.')){
      this.btnStatus = this.btnStatus === '' || this.btnStatus === 'pause' || this.btnStatus === 'reset' ? 'start' : 'pause';
      if (this.btnStatus === 'pause')
        this.pauseCount++
      else if (this.btnStatus === 'start')
        this.startCount++
      this.calculateTimer();
      this.resetButton = false;
    }
  }

  resetTimer() {
    this.btnStatus = 'reset';
    this.resetButton = true;
    this.resetAllValues();
    this.calculateTimer();
  }

  resetAllValues() {
    this.timerLim = 0;
    this.startCount = 0;
    this.pauseCount = 0;
    this.pauseValArr = [];
  }

  calculateTimer() {
    const timerValues = {
      timerLim: this.timerLim,
      btnStatus: this.btnStatus,
      startCount: this.startCount,
      pauseCount: this.pauseCount,
      time: this.getDateAndTime()
    }
    this.calculateTimerEvent.emit(timerValues)
  }

  getDateAndTime() {
    const date = new Date();
    const month = date.getMonth() + 1;
    return `${date.getDate()}-${month}-${date.getFullYear()} ${date.toLocaleTimeString()}`;
  }

}
