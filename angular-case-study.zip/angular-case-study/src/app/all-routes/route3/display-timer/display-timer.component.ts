import { Component, OnInit, Input, SimpleChanges, OnChanges, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-display-timer',
  templateUrl: './display-timer.component.html',
  styleUrls: ['./display-timer.component.css']
})
export class DisplayTimerComponent implements OnInit, OnChanges {

  @Input() timerValue:number;
  @Input() btnStatus: string;
  @Output() pauseValEvent = new EventEmitter<number>();
  localTimerVal: number = 0;
  interval:any;
  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!changes.timerValue?.firstChange && !changes.btnStatus?.firstChange) {
      if (this.timerValue && this.btnStatus === 'start') {
        if (!this.localTimerVal)
          this.localTimerVal = this.timerValue
        this.interval = setInterval(() => {
          this.localTimerVal--
          if (this.localTimerVal === 0)
            this.pauseTimer();
        }, 1000)
      }
      else if (this.btnStatus === 'reset') {
        this.localTimerVal = 0
        this.pauseTimer()
      }
      else if (this.btnStatus === 'pause') {
        this.pauseTimer();
        this.pauseValEvent.emit(this.localTimerVal);
      }
    }
  }

  pauseTimer() {
    clearInterval(this.interval);
  }

}
