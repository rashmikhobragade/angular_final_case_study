import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-log-time',
  templateUrl: './log-time.component.html',
  styleUrls: ['./log-time.component.css']
})
export class LogTimeComponent implements OnInit,OnChanges {
  
  logTimeArr = [];
  @Input() logTime:string;
  @Input() status:string;

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if(!changes.logTime.firstChange && !changes.status.firstChange){
      if(this.status === 'reset')
      this.logTimeArr = [];
      else
      this.logTimeArr.push({time:this.logTime,status:this.status});
    }
  }
}
