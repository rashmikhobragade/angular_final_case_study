import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-routes',
  templateUrl: './all-routes.component.html',
  styleUrls: ['./all-routes.component.css']
})
export class AllRoutesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
