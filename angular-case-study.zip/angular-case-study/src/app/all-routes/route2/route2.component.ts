import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route2',
  templateUrl: './route2.component.html',
  styleUrls: ['./route2.component.css']
})
export class Route2Component implements OnInit {
  products:any[] = [];
  view:string = 'grid';
  filterBy:string = '';

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get('./assets/data/product_data.json').subscribe((data:any[]) => {
      this.products = data;
    })
  }

  changeView(){
    this.view = this.view === 'grid' ? 'list' : 'grid';
  }

}
