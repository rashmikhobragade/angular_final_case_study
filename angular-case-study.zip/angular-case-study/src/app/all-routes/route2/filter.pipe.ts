import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any[], filterBy: string): any {
    if(filterBy === '')
    return value;
    else if(filterBy === 'asc')
    return value.sort((a,b)=>a.price - b.price);
    else if(filterBy === 'desc')
    return value.sort((a,b)=>b.price - a.price);
  }

}
